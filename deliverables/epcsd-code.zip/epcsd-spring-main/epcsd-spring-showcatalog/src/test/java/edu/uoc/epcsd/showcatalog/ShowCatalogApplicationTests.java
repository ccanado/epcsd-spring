package edu.uoc.epcsd.showcatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowCatalogApplicationTests {

    @Test
    void contextLoads() {
    }

}
