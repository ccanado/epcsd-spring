package edu.uoc.epcsd.showcatalog.dto;

import lombok.Data;

@Data
public class PerformanceDto {
    private String date;
    private String time;
    private String streamingURL;
}
